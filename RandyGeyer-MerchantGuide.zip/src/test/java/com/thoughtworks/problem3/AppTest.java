package com.thoughtworks.problem3;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.thoughtworks.problem3.App;

/**
 * Unit test fixture for simple {@link App}.
 * 
 * @author rgeyer
 *
 */
public class AppTest {
	
	/**
	 * Rigorous Test :-)
	 */
	@Test
	public void testApp() {
		assertTrue(true);
	}
}
